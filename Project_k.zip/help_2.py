import pygame
import os
import sys
import random


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()

    image = pygame.image.load(fullname)
    return image


def load_level(filename):
    filename = "data/" + filename
    # читаем уровень, убирая символы перевода строки
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]

    # и подсчитываем максимальную длину
    max_width = max(map(len, level_map))

    # дополняем каждую строку пустыми клетками ('.')
    return list(map(lambda x: x.ljust(max_width, '.'), level_map))


def terminate():
    pygame.quit()
    sys.exit()


def start_screen(WIDTH, HEIGHT):
    intro_text = ["ЗАСТАВКА", "",
                  "Правила игры",
                  "Если в правилах несколько строк,",
                  "приходится выводить их построчно"]

    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return True
        pygame.display.flip()
        clock.tick(FPS)


def generate_level(level):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Grass('empty', x, y)
            elif level[y][x] == '#':
                Block('wall', x, y)
            elif level[y][x] == '@':
                Grass('empty', x, y)
                new_player = Player(x, y)
    # вернем игрока, а также размер поля в клетках
    return new_player, x, y


tile_images = {
    'wall': load_image('box.png'),
    'empty': load_image('grass.png')
}
player_image = load_image('mario.png')

tile_width = tile_height = 50


class Block(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(block_group, all_sprites)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)


class Grass(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(grass_group, all_sprites)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)


class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = player_image
        self.rect = self.image.get_rect().move(
            tile_width * pos_x + 15, tile_height * pos_y + 5)
        self.change_x = 0
        self.change_y = 0

    def update(self):
        self.rect.x += self.change_x
        block_hit_list = []
        for block in block_group:
            if pygame.sprite.collide_mask(self, block):
                block_hit_list.append(block)

        for block in block_hit_list:
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                self.rect.left = block.rect.right

        self.rect.y += self.change_y
        block_hit_list = []
        for block in block_group:
            if pygame.sprite.collide_mask(self, block):
                block_hit_list.append(block)

        for block in block_hit_list:
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom

    def go_right(self):
        if self.rect.right < width:
            self.change_x = self.image.get_size()[0]

    def go_left(self):
        if self.rect.left > 0:
            self.change_x = -self.image.get_size()[0]

    def go_up(self):
        if self.rect.top > 0:
            self.change_y = -self.image.get_size()[1]

    def go_down(self):
        if self.rect.bottom < height:
            self.change_y = self.image.get_size()[1]


if __name__ == '__main__':
    pygame.init()
    width, height = 700, 500
    size = width, height
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption('Level')
    pygame.mouse.set_visible(True)

    running = True
    FPS = 60
    clock = pygame.time.Clock()

    player = None

    all_sprites = pygame.sprite.Group()
    block_group = pygame.sprite.Group()
    grass_group = pygame.sprite.Group()
    player_group = pygame.sprite.Group()

    if start_screen(width, height):
        player, level_x, level_y = generate_level(load_level('map.txt'))
    while running:
        screen.fill('black')
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.K_RIGHT:
                player.go_right()

            if event.type == pygame.K_LEFT:
                player.go_left()

            if event.type == pygame.K_UP:
                player.go_up()

            if event.type == pygame.K_DOWN:
                player.go_down()

        player_group.update()
        all_sprites.update()
        block_group.update()
        grass_group.update()
        all_sprites.draw(screen)
        block_group.draw(screen)
        grass_group.draw(screen)
        player_group.draw(screen)
        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
