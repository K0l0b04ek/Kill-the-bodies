import pygame
import os
import sys
# import random


def load_sound(name):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с аудиозаписью '{fullname}' не найден")
        sys.exit()

    return fullname


def load_image(name):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()

    image = pygame.image.load(fullname)
    return image


def load_level(filename):
    filename = "data/" + filename
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]
    max_width = max(map(len, level_map))
    return list(map(lambda x: x.ljust(max_width, '.'), level_map))


def save_changes():
    save = open(open_save('save.txt'), mode='w', encoding='utf-8')
    save.seek(0)
    save.write('fps ' + str(FPS))
    save.write('\n')
    save.write('volume ' + str(volume))
    save.close()


def load_save():
    save = open(open_save('save.txt'), mode='r', encoding='utf-8')
    x = save.read().split('\n')
    save.close()
    return x


def open_save(name):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с сохранением '{fullname}' не найден")
        sys.exit()

    return fullname


def terminate():
    save_changes()
    pygame.quit()
    sys.exit()


def exit_screen():
    exit_win_x, exit_win_y = 625, 375

    while True:
        fon.set_volume(volume / 100)
        screen.blit(tile_images['exit_win'], (exit_win_x, exit_win_y))
        screen.blit(tile_images['yes'], (exit_win_x + 110, exit_win_y + 110))
        screen.blit(tile_images['no'], (exit_win_x + 230, exit_win_y + 110))

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                terminate()
            elif ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    return
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_focused():
                    pos_x, pos_y = pygame.mouse.get_pos()
                    if exit_win_x + 110 <= pos_x <= exit_win_x + 170 and exit_win_y + 110 <= pos_y < exit_win_y + 140:
                        terminate()
                    if exit_win_x + 230 <= pos_x <= exit_win_x + 290 and exit_win_y + 110 <= pos_y < exit_win_y + 140:
                        return

        pygame.display.flip()
        clock.tick(FPS)


def start_screen():
    pygame.mouse.set_visible(True)
    intro_text = []
    fon.play(-1)

    while True:
        fon.set_volume(volume / 100)
        screen.fill('black')
        screen.blit(tile_images['play'], (1100, 100))
        screen.blit(tile_images['rules'], (1100, 330))
        screen.blit(tile_images['settings_2'], (1100, 510))
        screen.blit(tile_images['exit'], (1100, 690))

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                terminate()
            elif ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    exit_screen()
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_focused():
                    pos_x, pos_y = pygame.mouse.get_pos()
                    if 1100 <= pos_x <= 1500 and 100 <= pos_y < 300:
                        fon.stop()
                        return True
                    if 1100 <= pos_x <= 1500 and 330 <= pos_y < 480:
                        rules()
                    if 1100 <= pos_x <= 1500 and 510 <= pos_y < 660:
                        settings()
                    if 1100 <= pos_x <= 1500 and 690 <= pos_y < 840:
                        exit_screen()

        pygame.display.flip()
        clock.tick(FPS)


def pause_menu():
    pygame.mouse.set_visible(True)
    menu_x, menu_y = 625, 225

    while True:
        fon.set_volume(volume / 100)
        screen.blit(tile_images['menu'], (menu_x, menu_y))
        screen.blit(tile_images['resume'], (menu_x + 100, menu_y + 150))
        screen.blit(tile_images['settings'], (menu_x + 100, menu_y + 250))
        screen.blit(tile_images['quit'], (menu_x + 100, menu_y + 350))

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                terminate()
            elif ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    return True
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_focused():
                    pos_x, pos_y = pygame.mouse.get_pos()
                    if menu_x + 100 <= pos_x <= menu_x + 300 and menu_y + 150 <= pos_y < menu_y + 200:
                        return True
                    elif menu_x + 100 <= pos_x <= menu_x + 300 and menu_y + 250 <= pos_y < menu_y + 300:
                        settings()
                    elif menu_x + 100 <= pos_x <= menu_x + 300 and menu_y + 350 <= pos_y < menu_y + 400:
                        return False

        pygame.display.flip()
        clock.tick(FPS)


def rules():
    rules_win_x, rules_win_y = 575, 175
    rules_text = ["ЗАСТАВКА", "",
                  "Правила игры",
                  "Если в правилах несколько строк,",
                  "приходится выводить их построчно"]

    fon_im = pygame.transform.scale(load_image('fon.jpg'), (width, height))
    screen.blit(fon_im, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in rules_text:
        string_rendered = font.render(line, True, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        fon.set_volume(volume / 100)
        screen.blit(tile_images['rules_win'], (rules_win_x, rules_win_y))
        screen.blit(tile_images['back'], (rules_win_x + 175, rules_win_y + 500))

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                terminate()
            elif ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    return
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_focused():
                    pos_x, pos_y = pygame.mouse.get_pos()
                    if rules_win_x + 175 <= pos_x <= rules_win_x + 325 \
                            and rules_win_y + 500 <= pos_y < rules_win_y + 550:
                        return

        pygame.display.flip()
        clock.tick(FPS)


def settings():
    global FPS, volume
    pygame.mouse.set_visible(True)
    set_win_x, set_win_y = 625, 225
    font = pygame.font.Font(None, 50)

    while True:
        fon.set_volume(volume / 100)
        screen.blit(tile_images['settings_win'], (set_win_x, set_win_y))
        screen.blit(tile_images['volume'], (set_win_x + 100, set_win_y + 150))
        screen.blit(tile_images['vol_place'], (set_win_x + 150, set_win_y + 150))
        screen.blit(font.render(' ' + str(volume) + ' %', True, pygame.Color('#FF8C00')),
                    (set_win_x + 147, set_win_y + 160))
        if volume < 100:
            screen.blit(tile_images['arrow_up'], (set_win_x + 260, set_win_y + 150))
        if volume > 0:
            screen.blit(tile_images['arrow_down'], (set_win_x + 260, set_win_y + 175))
        screen.blit(tile_images['fps'], (set_win_x + 100, set_win_y + 250))
        screen.blit(tile_images['fps_place'], (set_win_x + 160, set_win_y + 250))
        screen.blit(font.render(' ' + str(FPS) + ' ', True, pygame.Color('#FF8C00')),
                    (set_win_x + 170, set_win_y + 260))
        if FPS < 120:
            screen.blit(tile_images['arrow_up'], (set_win_x + 260, set_win_y + 250))
        if FPS > 20:
            screen.blit(tile_images['arrow_down'], (set_win_x + 260, set_win_y + 275))
        screen.blit(tile_images['back'], (set_win_x + 125, set_win_y + 375))

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                terminate()
            elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                return
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_focused():
                    pos_x, pos_y = pygame.mouse.get_pos()
                    if set_win_x + 125 <= pos_x <= set_win_x + 275 and set_win_y + 375 <= pos_y < set_win_y + 425:
                        return
                    if set_win_x + 260 <= pos_x <= set_win_x + 300 and set_win_y + 150 <= pos_y < set_win_y + 175:
                        if volume < 100:
                            volume += 10
                    if set_win_x + 260 <= pos_x <= set_win_x + 300 and set_win_y + 175 <= pos_y < set_win_y + 200:
                        if volume > 0:
                            volume -= 10
                    if set_win_x + 260 <= pos_x <= set_win_x + 300 and set_win_y + 250 <= pos_y < set_win_y + 275:
                        if FPS < 120:
                            FPS += 10
                    if set_win_x + 260 <= pos_x <= set_win_x + 300 and set_win_y + 275 <= pos_y < set_win_y + 300:
                        if FPS > 20:
                            FPS -= 10

        pygame.display.flip()
        clock.tick(FPS)


def generate_level(lvl):
    new_player, x, y = None, None, None
    for y in range(len(lvl)):
        for x in range(len(lvl[y])):
            if lvl[y][x] == '.':
                Grass('empty', x, y)
            elif lvl[y][x] == '#':
                Block('wall', x, y)
            elif lvl[y][x] == '@':
                Grass('empty', x, y)
                new_player = Player(x, y)
    return new_player, x, y


tile_images = {
    'wall': load_image('box.png'),
    'empty': load_image('grass.png'),
    'settings': load_image('settings.png'),
    'quit': load_image('quit.png'),
    'resume': load_image('resume.png'),
    'volume': load_image('volume.png'),
    'player': load_image('mario.png'),
    'back': load_image('back.png'),
    'rules': load_image('rules.png'),
    'menu': load_image('menu.png'),
    'settings_win': load_image('settings_win.png'),
    'arrow_up': load_image('arrow_up.png'),
    'arrow_down': load_image('arrow_down.png'),
    'fps': load_image('fps.png'),
    'fps_place': load_image('fps_place.png'),
    'vol_place': load_image('vol_place.png'),
    'play': load_image('play.png'),
    'settings_2': load_image('settings_2.png'),
    'exit': load_image('exit.png'),
    'rules_win': load_image('rules_win.png'),
    'yes': load_image('yes.png'),
    'no': load_image('no.png'),
    'exit_win': load_image('exit_win.png')
}

tile_width = tile_height = ceil = 50


class Block(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(block_group, all_sprites)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)


class Grass(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(grass_group, all_sprites)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)


class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = tile_images['player']
        self.rect = self.image.get_rect()
        self.rect.x = tile_width * pos_x + 15
        self.rect.y = tile_height * pos_y + 5
        self.change_x = 0
        self.change_y = 0
        self.left_sight = True

    def update(self):
        self.rect.x += self.change_x
        block_hit_list = []
        for block in block_group:
            if pygame.sprite.collide_mask(self, block):
                block_hit_list.append(block)

        for block in block_hit_list:
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                self.rect.left = block.rect.right

        self.rect.y += self.change_y
        block_hit_list = []
        for block in block_group:
            if pygame.sprite.collide_mask(self, block):
                block_hit_list.append(block)

        for block in block_hit_list:
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom

    def go_right(self):
        if self.rect.right < width:
            self.change_x = 2
            if self.left_sight:
                self.flip()
                self.left_sight = False

    def go_left(self):
        if self.rect.left > 0:
            self.change_x = -2
            if not self.left_sight:
                self.flip()
                self.left_sight = True

    def go_up(self):
        if self.rect.top > 0:
            self.change_y = -2

    def go_down(self):
        if self.rect.bottom < height:
            self.change_y = 2

    def stop_x(self):
        self.change_x = 0

    def stop_y(self):
        self.change_y = 0

    def flip(self):
        self.image = pygame.transform.flip(self.image, True, False)


class Camera:
    def __init__(self):
        self.dx = 0
        self.dy = 0

    def apply(self, obj):
        obj.rect.x += self.dx
        obj.rect.y += self.dy

    def update(self, target):
        self.dx = -(target.rect.x + target.rect.w // 2 - width // 2)
        self.dy = -(target.rect.y + target.rect.h // 2 - height // 2)


if __name__ == '__main__':
    pygame.mixer.pre_init(44100, -16, 1, 512)
    pygame.init()
    width, height = 1650, 950
    size = width, height
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption('Level')
    pygame.mouse.set_visible(True)

    running = False
    fon = pygame.mixer.Sound(load_sound('Happy Walk.mp3'))
    for x in load_save():
        x = x.split()
        if x[0] == 'fps':
            FPS = int(x[1])
        elif x[0] == 'volume':
            volume = int(x[1])
    clock = pygame.time.Clock()

    while True:
        if start_screen():
            player = None
            camera = Camera()

            all_sprites = pygame.sprite.Group()
            block_group = pygame.sprite.Group()
            grass_group = pygame.sprite.Group()
            player_group = pygame.sprite.Group()
            pause_menu_buttons = pygame.sprite.Group()
            settings_buttons = pygame.sprite.Group()

            player, level_x, level_y = generate_level(load_level('map.txt'))
            pygame.mouse.set_visible(False)
            running = True

        while running:
            screen.fill('black')
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    terminate()

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RIGHT:
                        player.go_right()

                    if event.key == pygame.K_LEFT:
                        player.go_left()

                    if event.key == pygame.K_UP:
                        player.go_up()

                    if event.key == pygame.K_DOWN:
                        player.go_down()

                    if event.key == pygame.K_ESCAPE:
                        player.stop_y()
                        player.stop_x()
                        running = pause_menu()
                        event.key = None

                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT and player.change_x < 0:
                        player.stop_x()

                    if event.key == pygame.K_RIGHT and player.change_x > 0:
                        player.stop_x()

                    if event.key == pygame.K_UP and player.change_y < 0:
                        player.stop_y()

                    if event.key == pygame.K_DOWN and player.change_y > 0:
                        player.stop_y()

            camera.update(player)
            for sprite in all_sprites:
                camera.apply(sprite)
            all_sprites.update()
            player_group.update()
            all_sprites.draw(screen)
            block_group.draw(screen)
            grass_group.draw(screen)
            player_group.draw(screen)
            pygame.display.flip()
            clock.tick(FPS)
